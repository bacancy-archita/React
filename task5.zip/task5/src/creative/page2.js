import React, { Component } from 'react';
//import { Route, Link } from 'react-router-dom'

class Page2 extends Component {
    render() {
        return (
            <div>
                <h1>This is page 2</h1>
            </div>
        );
    }
}

export default Page2;
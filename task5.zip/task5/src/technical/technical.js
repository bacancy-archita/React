import React, { Component } from 'react';
//import {Route} from 'react-router-dom';
import Topbar from './topbar';

class Technical extends Component {
  render() {
    return (
      <div>
          <div>
            <Topbar/>
          </div>
      </div>
    );
  }
}
export default Technical;
